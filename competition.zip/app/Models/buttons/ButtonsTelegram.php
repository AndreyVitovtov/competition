<?php

namespace App\Models\buttons;

use App\Models\buttons\extend\AbstractButtonsTelegram;

class ButtonsTelegram extends AbstractButtonsTelegram {

//    public function menu() {
//        return [
//          ['button', 'button'],
//          ['button']
//        ];
//    }
}
