<?php


namespace App\Models;

class PerformAction {
    public static function pay($id, $amount, $context) {

    }
}
