<a href="{{ $url }}">
    <li class="item-menu {{ $menu }}">
        <div>
            <div>
                <i class="{{ $icon }}"></i> <span>@lang('menu.'.$name)</span>
            </div>
            <div></div>
        </div>
    </li>
</a>
