<?php

return json_decode(file_get_contents(public_path('json/lang/ru/menu.json')), true);
