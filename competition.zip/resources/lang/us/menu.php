<?php

return json_decode(file_get_contents(public_path('json/lang/us/menu.json')), true);
